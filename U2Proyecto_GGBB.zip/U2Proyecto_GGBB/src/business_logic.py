# src/business_logic.py
from datetime import date
from dateutil.relativedelta import relativedelta
from flask import jsonify, flash
from .db import get_db_connection
import requests
from datetime import datetime, timedelta

#DETECTAR MORA
def check_loan_mora():
    """Ejecuta el procedimiento almacenado en la BD para revisar y actualizar
    el estado de los préstamos en mora, asegurando SERIALIZABLE isolation.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        #Establecer el nivel de aislamiento
        cursor.execute("SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE")
        
        #Llamada al Procedimiento Almacenado 'update_loan_mora'
        cursor.callproc('update_loan_mora')
        conn.commit() 
        print("Mantenimiento de mora ejecutado exitosamente (vía SP).")
    except Exception as e:
        print(f"Error al ejecutar Procedimiento Almacenado de mora: {e}")
        conn.rollback()
    finally:
        cursor.close()
        conn.close()


def disburse_loan_logic(loan_id, conn):
    cursor = conn.cursor(dictionary=True)
    try:
        #Obtener datos con nombres de columna reales
        cursor.execute("""
            SELECT user_id, amount, duration_months, interest_rate 
            FROM loans WHERE id = %s
        """, (loan_id,))
        loan = cursor.fetchone()
        
        if not loan: return False

        # Transacción: El estado solo cambia si todo lo demás funciona
        cursor.execute("UPDATE loans SET status='ACTIVO', start_date=CURDATE() WHERE id=%s", (loan_id,))
        cursor.execute("SAVEPOINT prestamo_activo")

        # Registro en Transactions
        cursor.execute("""
            INSERT INTO transactions (user_id, loan_id, type, amount, description) 
            VALUES (%s, %s, 'DESEMBOLSO_CREDITO', %s, %s)
        """, (loan['user_id'], loan_id, loan['amount'], f"Desembolso Préstamo #{loan_id}"))

        # Generar Amortización con columnas reales
        total_prestamo = float(loan['amount'])
        meses = loan['duration_months']
        tasa_mensual = (float(loan['interest_rate']) / 100)
        
        capital_cuota = total_prestamo / meses
        interes_cuota = (total_prestamo * tasa_mensual) / meses

        for i in range(1, meses + 1):
            # Calcular fecha de vencimiento
            fecha_vencimiento = datetime.now() + timedelta(days=30 * i)
            
            cursor.execute("""
                INSERT INTO amortization_schedule 
                (loan_id, installment_number, due_date, amount_capital, amount_interest, total_amount, payment_status) 
                VALUES (%s, %s, %s, %s, %s, %s, 'PENDIENTE')
            """, (loan_id, i, fecha_vencimiento.date(), capital_cuota, interes_cuota, capital_cuota + interes_cuota))

        return True 

    except Exception as e:
        print(f"Falla crítica en desembolso: {e}")
        # El rollback automático asegura que no existan datos huérfanos
        return False
    
def preparar_para_desembolso(loan_id, conn):
    cursor = conn.cursor()
    try:
        cursor.callproc('validar_y_preparar_desembolso', [loan_id])
        return True
    except Exception as e:
        print(f"Validación rechazada: {e}")
        return False