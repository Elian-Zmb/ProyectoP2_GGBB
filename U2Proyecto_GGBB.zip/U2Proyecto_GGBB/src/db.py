import mysql.connector
from flask import session

def get_admin_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='07081983',
        database='sociedad_financiera'
    )

def get_db_connection():
    creds = {
        'SECRETARIO': ('login_secretaria', 'Sec@Finan_2025'),
        'TESORERO': ('login_tesoreria', 'Tes@Finan_2025'),
        'DIRECTOR': ('login_director', 'Dir@Finan_2025'),
        'SOCIO': ('login_auditor', 'Aud@Finan_2025') 
    }
    
    user_db, pass_db = creds.get(session.get('role'), ('login_auditor', 'Aud@Finan_2025'))

    return mysql.connector.connect(
        host='localhost',
        user=user_db,
        password=pass_db,
        database='sociedad_financiera'
    )