from flask import Blueprint, render_template, redirect, url_for, session, request, flash
from functools import wraps
from werkzeug.security import check_password_hash, generate_password_hash
from .db import get_db_connection

auth_bp = Blueprint('auth', __name__)

#DECORADOR DE SEGURIDAD
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.index'))
        return f(*args, **kwargs)
    return decorated_function

#RUTAS DE AUTENTICACIÓN
@auth_bp.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('routes.dashboard', section='resumen'))
    return render_template('login.html')

@auth_bp.route('/login', methods=['POST'])
def login():
    dni_ingresado = request.form['user_id']
    password_ingresada = request.form['password']
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    # Buscamos al usuario por su DNI
    cursor.execute("SELECT * FROM users WHERE dni = %s AND status = 1", (dni_ingresado,))
    usuario = cursor.fetchone()
    conn.close()
    
    # Verificar si el usuario existe y la contraseña coincide
    if usuario and check_password_hash(usuario['password_hash'], password_ingresada):
        
        #ESCENARIO DE RESTRICCIÓN: Solo Socios y Staff
        roles_permitidos = ['SOCIO', 'SECRETARIO', 'DIRECTOR', 'TESORERO']
        
        if usuario['role'] not in roles_permitidos:
            flash("Acceso restringido: Su perfil no cuenta con permisos de acceso al sistema.", 'error')
            return redirect(url_for('auth.index'))
            
        #Creación de Sesión
        session['user_id'] = usuario['id']
        session['role'] = usuario['role']
        session['name'] = usuario['full_name']
        
        flash(f"Bienvenido al sistema, {usuario['full_name']}", 'success')
        return redirect(url_for('routes.dashboard', section='resumen'))
    
    else:
        flash("Cédula o Contraseña incorrecta. Intente de nuevo.", 'error')
        return redirect(url_for('auth.index'))

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.index'))

#FUNCIÓN AUXILIAR
def crear_hash_password(password_plana):
    """Genera un hash seguro para cumplir con las Buenas Prácticas"""
    return generate_password_hash(password_plana)