import os

gtk_bin = r"C:\msys64\ucrt64\bin"
if os.path.exists(gtk_bin):
    os.add_dll_directory(gtk_bin)
    os.environ['PATH'] = gtk_bin + os.pathsep + os.environ.get('PATH', '')
    
from flask import Flask
from src.auth import auth_bp
from src.routes import routes_bp
from src.business_logic import check_loan_mora
from apscheduler.schedulers.background import BackgroundScheduler
import atexit



app = Flask(__name__)
app.secret_key = 'super_secreto_sociedad_financiera' 

#REGISTRO DE BLUEPRINTS
app.register_blueprint(auth_bp)
app.register_blueprint(routes_bp)

#CONFIGURACIÓN DEL PROGRAMADOR DE TAREAS
scheduler = BackgroundScheduler()

#Ejecutar check_loan_mora() una vez al día a medianoche
scheduler.add_job(func=check_loan_mora, trigger='cron', hour=0, minute=0, id='mora_diaria')

scheduler.start()

# Asegurarse de que el programador se apague al salir de la aplicación
atexit.register(lambda: scheduler.shutdown())

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)